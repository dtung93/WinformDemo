﻿
namespace TungD
{
    partial class Product
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtmsp = new System.Windows.Forms.TextBox();
            this.txtinfo = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtprice = new System.Windows.Forms.TextBox();
            this.cboxcategory = new System.Windows.Forms.ComboBox();
            this.numquantity = new System.Windows.Forms.NumericUpDown();
            this.status = new System.Windows.Forms.CheckBox();
            this.dgvproduct = new System.Windows.Forms.DataGridView();
            this.colmsp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coltensp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colthongtin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colgiatien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colsoluong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colphanloaisp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coltrangthai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numquantity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvproduct)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ma SP";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ten SP";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Thong Tin";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 129);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Gia Tien";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(415, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "SL ton kho";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(415, 56);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Phan Loai SP";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(415, 88);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Trang Thai";
            // 
            // txtmsp
            // 
            this.txtmsp.Location = new System.Drawing.Point(109, 19);
            this.txtmsp.Name = "txtmsp";
            this.txtmsp.Size = new System.Drawing.Size(198, 20);
            this.txtmsp.TabIndex = 7;
            // 
            // txtinfo
            // 
            this.txtinfo.Location = new System.Drawing.Point(109, 88);
            this.txtinfo.Name = "txtinfo";
            this.txtinfo.Size = new System.Drawing.Size(198, 20);
            this.txtinfo.TabIndex = 8;
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(109, 56);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(198, 20);
            this.txtname.TabIndex = 9;
            // 
            // txtprice
            // 
            this.txtprice.Location = new System.Drawing.Point(109, 126);
            this.txtprice.Name = "txtprice";
            this.txtprice.Size = new System.Drawing.Size(198, 20);
            this.txtprice.TabIndex = 10;
            // 
            // cboxcategory
            // 
            this.cboxcategory.FormattingEnabled = true;
            this.cboxcategory.Location = new System.Drawing.Point(532, 53);
            this.cboxcategory.Name = "cboxcategory";
            this.cboxcategory.Size = new System.Drawing.Size(147, 21);
            this.cboxcategory.TabIndex = 13;
            // 
            // numquantity
            // 
            this.numquantity.Location = new System.Drawing.Point(532, 11);
            this.numquantity.Name = "numquantity";
            this.numquantity.Size = new System.Drawing.Size(147, 20);
            this.numquantity.TabIndex = 14;
            // 
            // status
            // 
            this.status.AutoSize = true;
            this.status.Location = new System.Drawing.Point(532, 90);
            this.status.Name = "status";
            this.status.Size = new System.Drawing.Size(62, 17);
            this.status.TabIndex = 15;
            this.status.Text = "Active?";
            this.status.UseVisualStyleBackColor = true;
            // 
            // dgvproduct
            // 
            this.dgvproduct.AllowUserToAddRows = false;
            this.dgvproduct.AllowUserToDeleteRows = false;
            this.dgvproduct.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvproduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvproduct.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colmsp,
            this.coltensp,
            this.colthongtin,
            this.colgiatien,
            this.colsoluong,
            this.colphanloaisp,
            this.coltrangthai});
            this.dgvproduct.Location = new System.Drawing.Point(3, 182);
            this.dgvproduct.Name = "dgvproduct";
            this.dgvproduct.ReadOnly = true;
            this.dgvproduct.RowHeadersVisible = false;
            this.dgvproduct.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvproduct.Size = new System.Drawing.Size(785, 243);
            this.dgvproduct.TabIndex = 16;
            this.dgvproduct.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvproduct_CellDoubleClick);
            this.dgvproduct.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvproduct_KeyUp);
            // 
            // colmsp
            // 
            this.colmsp.DataPropertyName = "masp";
            this.colmsp.HeaderText = "Ma SP";
            this.colmsp.Name = "colmsp";
            this.colmsp.ReadOnly = true;
            // 
            // coltensp
            // 
            this.coltensp.DataPropertyName = "tensp";
            this.coltensp.HeaderText = "Ten SP";
            this.coltensp.Name = "coltensp";
            this.coltensp.ReadOnly = true;
            // 
            // colthongtin
            // 
            this.colthongtin.DataPropertyName = "info";
            this.colthongtin.HeaderText = "Thong Tin";
            this.colthongtin.Name = "colthongtin";
            this.colthongtin.ReadOnly = true;
            // 
            // colgiatien
            // 
            this.colgiatien.DataPropertyName = "price";
            this.colgiatien.HeaderText = "Gia Tien";
            this.colgiatien.Name = "colgiatien";
            this.colgiatien.ReadOnly = true;
            // 
            // colsoluong
            // 
            this.colsoluong.DataPropertyName = "SL";
            this.colsoluong.HeaderText = "SL kho";
            this.colsoluong.Name = "colsoluong";
            this.colsoluong.ReadOnly = true;
            // 
            // colphanloaisp
            // 
            this.colphanloaisp.DataPropertyName = "maloai";
            this.colphanloaisp.HeaderText = "Phan Loai SP";
            this.colphanloaisp.Name = "colphanloaisp";
            this.colphanloaisp.ReadOnly = true;
            // 
            // coltrangthai
            // 
            this.coltrangthai.DataPropertyName = "status";
            this.coltrangthai.HeaderText = "Trang Thai";
            this.coltrangthai.Name = "coltrangthai";
            this.coltrangthai.ReadOnly = true;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(440, 129);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 17;
            this.btnAdd.Text = "Them SP";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(532, 129);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(75, 23);
            this.btnEdit.TabIndex = 18;
            this.btnEdit.Text = "Sua";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // Product
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.dgvproduct);
            this.Controls.Add(this.status);
            this.Controls.Add(this.numquantity);
            this.Controls.Add(this.cboxcategory);
            this.Controls.Add(this.txtprice);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.txtinfo);
            this.Controls.Add(this.txtmsp);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Product";
            this.Text = "Product";
            this.Load += new System.EventHandler(this.Product_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numquantity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvproduct)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtmsp;
        private System.Windows.Forms.TextBox txtinfo;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtprice;
        private System.Windows.Forms.ComboBox cboxcategory;
        private System.Windows.Forms.NumericUpDown numquantity;
        private System.Windows.Forms.CheckBox status;
        private System.Windows.Forms.DataGridView dgvproduct;
        private System.Windows.Forms.DataGridViewTextBoxColumn colmsp;
        private System.Windows.Forms.DataGridViewTextBoxColumn coltensp;
        private System.Windows.Forms.DataGridViewTextBoxColumn colthongtin;
        private System.Windows.Forms.DataGridViewTextBoxColumn colgiatien;
        private System.Windows.Forms.DataGridViewTextBoxColumn colsoluong;
        private System.Windows.Forms.DataGridViewTextBoxColumn colphanloaisp;
        private System.Windows.Forms.DataGridViewTextBoxColumn coltrangthai;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnEdit;
    }
}